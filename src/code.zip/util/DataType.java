package util;

public enum DataType {
    VOID, INT, ONE, TWO
}
