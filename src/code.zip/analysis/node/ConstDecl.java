package analysis.node;

import util.NodeType;

public class ConstDecl extends Node {
    public ConstDecl() {
        super(NodeType.CONSTDECL);
    }

}
