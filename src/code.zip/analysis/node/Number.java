package analysis.node;

import util.NodeType;

public class Number extends Node {
    public Number() {
        super(NodeType.NUMBER);
    }
}
