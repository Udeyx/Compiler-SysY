package analysis.node.func;

import util.NodeType;
import analysis.node.Node;

public class FuncType extends Node {
    public FuncType() {
        super(NodeType.FUNCTYPE);
    }
}
