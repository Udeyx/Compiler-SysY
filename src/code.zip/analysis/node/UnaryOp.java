package analysis.node;

import util.NodeType;

public class UnaryOp extends Node {
    public UnaryOp() {
        super(NodeType.UNARYOP);
    }
}
