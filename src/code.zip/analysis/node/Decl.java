package analysis.node;

import util.NodeType;

public class Decl extends Node {
    public Decl() {
        super(NodeType.DECL);
    }
}
