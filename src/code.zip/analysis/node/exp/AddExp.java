package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class AddExp extends Node {
    public AddExp() {
        super(NodeType.ADDEXP);
    }
}
