package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class RelExp extends Node {
    public RelExp() {
        super(NodeType.RELEXP);
    }
}
