package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class ConstExp extends Node {
    public ConstExp() {
        super(NodeType.CONSTEXP);
    }
}
