package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class LOrExp extends Node {
    public LOrExp() {
        super(NodeType.LOREXP);
    }
}
