package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class MulExp extends Node {
    public MulExp() {
        super(NodeType.MULEXP);
    }
}
