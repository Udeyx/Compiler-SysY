package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class LAndExp extends Node {
    public LAndExp() {
        super(NodeType.LANDEXP);
    }
}
