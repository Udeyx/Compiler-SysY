package analysis.node.exp;

import util.NodeType;
import analysis.node.Node;

public class EqExp extends Node {
    public EqExp() {
        super(NodeType.EQEXP);
    }
}
