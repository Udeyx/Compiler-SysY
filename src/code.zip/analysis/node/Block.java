package analysis.node;

import util.NodeType;

public class Block extends Node {
    public Block() {
        super(NodeType.BLOCK);
    }
}
