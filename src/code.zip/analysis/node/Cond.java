package analysis.node;

import util.NodeType;

public class Cond extends Node {
    public Cond() {
        super(NodeType.COND);
    }
}
