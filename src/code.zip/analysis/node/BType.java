package analysis.node;

import util.NodeType;

public class BType extends Node {
    public BType() {
        super(NodeType.BTYPE);
    }
}
