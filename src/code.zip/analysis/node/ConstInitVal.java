package analysis.node;

import util.NodeType;

public class ConstInitVal extends Node {
    public ConstInitVal() {
        super(NodeType.CONSTINITVAL);
    }
}
