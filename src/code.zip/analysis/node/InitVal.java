package analysis.node;

import util.NodeType;

public class InitVal extends Node {
    public InitVal() {
        super(NodeType.INITVAL);
    }
}
