package analysis.node;

import util.NodeType;

public class BlockItem extends Node {
    public BlockItem() {
        super(NodeType.BLOCKITEM);
    }
}
