package analysis.node;

import util.NodeType;

public class ForStmt extends Node {
    public ForStmt() {
        super(NodeType.FORSTMT);
    }
}
